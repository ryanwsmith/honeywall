#!/usr/bin/perl
#
# $Id: Rule.pm,v 1.36 2007/01/16 00:45:39 bmc Exp $
#
# Copyright (C) 2003 Brian Caswell <bmc@shmoo.com>
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
# 3. All advertising materials mentioning features or use of this software
#    must display the following acknowledgement:
#       This product includes software developed by Brian Caswell.
# 4. The name of the author may not be used to endorse or promote products
#    derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
# IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
# OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
# NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
# THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
# THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#

=head1 NAME

Net::Snort::Parser::Rule - Perl interface to parsing snort rules

=head1 SYNOPSIS

use Net::Snort::Parser::Rule;

my $parser = Net::Snort::Parser::Rule->new();
my $rule = $parser->parse_rule($ruletext);

=head1 DESCRIPTION

Net::Snort::Parser::File is a module that provides a mechanism for parsing snort rules, handling most of the "isms" that the snort parser forces on application developers.

Programmers that use this module should be familar with the snort rules format, since many requirements of the rules language are implied by this module.

=head1 NOTES

This module does not handle multiline rules.  That should be handled before passing the rule to the parser.

=head1 AUTHOR

Brian Caswell <bmc@shmoo.com>

=head1 REPORTING BUGS

Report bugs to <bmc@shmoo.com>

=head1 THANKS

Thanks to The Honeynet Project

=head1 COPYRIGHT

Copyright (c) 2003 Brian Caswell <bmc@shmoo.com>

=head1 SEE ALSO

L<snort(8)>

=cut

package Net::Snort::Parser::Rule;

use Net::Snort::Parser::RuleOptions;
use strict;
use warnings;
use Exporter;
use vars qw($AUTOLOAD $VERSION @ISA @EXPORT);

$VERSION = (qw($Revision: 1.36 $))[1];
@ISA     = qw(Exporter);
@EXPORT  = qw(parse_rule test_rule);

my $DEBUG = 0;

my $rule =
'# alert tcp $EXTERNAL_NET any -> $HOME_NET 32771:34000 (msg:"RPC kcms_server directory traversal attempt"; flow:to_server,established; content:"|00 00 00 00|"; offset:8; depth:4; content:"|00 01 87 7D|"; offset:16; depth:4; byte_jump:4,20,relative,align; byte_jump:4,4,relative,align; content:"/../"; distance:0; reference:cve,CAN-2003-0027; reference:url,www.kb.cert.org/vuls/id/850785; classtype:misc-attack; sid:2007; rev:5;)';

my @actions   = qw(alert drop log pass reject sdrop);
my @protocols = qw(ip tcp udp icmp);

my $ACTION_RE = join("|", @actions);
my $PROTO_RE  = join("|", @protocols);

my $VARIABLE_RE = '\$[\w_]+';
my $PORT_NUMBER = '(?:' . join('|', '\d{1,4}', '[1-5]\d{4}', '6[0-4]\d{3}', '65[0-4]\d{2}', '655[0-2]\d', '6553[0-5]') . ')';
my $PORT_RE     = join('|', 'any', $VARIABLE_RE, '\x21?(?:' . join('|' , $PORT_NUMBER, $PORT_NUMBER . ':', $PORT_NUMBER . ':' . $PORT_NUMBER, ':' . $PORT_NUMBER) . ')');


my $_IP = qr/(?:(?:25[0-5]|2[0-4]\d|[01]?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d?\d)/;
my $_NETMASK = qr/(?:3[12]|[12]\d|\d)/;
my $_IP_NETMASK = qr/$_IP(?:\x2f$_NETMASK)?/;
my $IP_RE = join('|', 'any', $VARIABLE_RE, '\x21?(?:' . join('|', $_IP_NETMASK, '\[\x21?\s*' . $_IP_NETMASK . '(?:,\s*\x21?\s*' . $_IP_NETMASK .'){1,}\s*\]') .')');

my $DIR_RE     = "->|<>";
my $CONTENT_RE = '\((.*)\)\s*$';

my $RULE_RE = '^\s*#?\s*' .  join('\s+', map ('(' . $_ . ')', $ACTION_RE, $PROTO_RE, $IP_RE, $PORT_RE, $DIR_RE, $IP_RE, $PORT_RE)) . '\s+' . $CONTENT_RE . '\s*$';

my %fields = (rule => undef);
            
my $opt_parser = Net::Snort::Parser::RuleOptions->new();

sub new {
    my $that  = shift;
    my $class = ref($that) || $that;
    my $self  = {
        %fields,
    };

    bless $self, $class;

    if (@_) {
        my %conf = @_;
        while (my ($k, $v) = each %conf) {
            $self->$k($v);
        }
    }

    $self->max_ruleopt_len(65536);
    return $self;
}

sub AUTOLOAD {
    my $self = shift;

    # my $type = ref($self) || die "$self is not an object";
    my $name = $AUTOLOAD;

    if (@_) {
        return $self->{$name} = shift;
    } else {
        return $self->{$name};
    }
}

sub self_or_default {
    return @_
      if defined($_[0])
      && (!ref($_[0]))
      && ($_[0] eq 'Net::Snort::Parser::Rule');

    my $q;

    # slightly optimized for common case
    unless (
        defined($_[0])
        && (ref($_[0]) eq 'Net::Snort::Parser::Rule'
            || UNIVERSAL::isa($_[0], 'Net::Snort::Parser::Rule'))
      )
    {
        $q = Net::Snort::Parser::Rule->new;
        unshift(@_, $q);
    }
    return wantarray ? @_ : $q;
}

    
sub verify_noalert {
    my ($rule) = @_;
    my %metadata_types =
    map { $_, 1 } qw(reference classtype msg sid rev metadata);
    my $noalert;
    foreach my $id (sort { $a <=> $b } keys %{ $rule->{'options'} }) {
        my $type = $rule->{'options'}{$id}{'type'};
        if ($type eq 'flowbits') {
            if ($rule->{'options'}{$id}{'args'} eq 'noalert') {
                $noalert++;
            }
        } elsif ($noalert && !defined($metadata_types{$type})) {
            return failed('noalert before a non-metadata rule option');
        }
    }
    return;
}

sub verify_relative {
    my ($rule) = @_;

    foreach my $id (sort { $a <=> $b } keys %{ $rule->{'options'} }) {
        my $option = $rule->{'options'}{$id};

        if ($option->{'type'} eq 'content') {
            if ($option->{'relative'}) {
                return failed("the first content is relative");
            }
            last;
        } elsif ($option->{'type'} eq 'pcre') {
            if ($option->{'args'} =~ /.*\/\w*R\w*$/) {
                return failed("the first pcre is relative");
            }
            last;
        } elsif ($option->{'type'} eq 'byte_jump') {
            if ($option->{'args'} =~ /relative/) {
                return failed("the first byte_jump is relative");
            }
            last;
        }

        # the rest of the opts don't set doe, just check it
        elsif ($option->{'type'} eq 'byte_test') {
            if ($option->{'args'} =~ /relative/) {
                return failed("the first byte_test is relative");
            }
        } elsif ($option->{'type'} eq 'isdataat') {
            if ($option->{'args'} =~ /relative/) {
                return failed("the first isdataat is relative");
            }
        }
    }
    return;
}

sub verify_class {
    my ($rule) = @_;
    if (!defined($rule->{'classification'})) {
        return failed('rules must have a valid classification');
    }
}

sub parse_rule {
    my ($self, @p) = self_or_default(@_);
    my ($rule) = (@p);

    my %rule = ('original' => $rule);

    if ($rule =~ s/^\s*\#\s*//) {
        $rule{'state'} = 0;
    } else {
        $rule{'state'} = 1;
    }

    if ($rule =~ /$RULE_RE/i) {
        $rule{'action'}    = $1;
        $rule{'protocol'}  = lc($2);
        $rule{'src'}       = $3;
        $rule{'srcport'}   = $4;
        $rule{'direction'} = $5;
        $rule{'dst'}       = $6;
        $rule{'dstport'}   = $7;
        $rule{'_rest'}     = $8;
    } else {
        warn "base rule failure\n" if ($DEBUG);
        return;
    }

    my $options = parse_options($rule{'_rest'});

    # if rule option parsing failed, then pass the bitch up.
    if ($rule{'_rest'} && !defined($options)) {
        return failed("parse options failed");
    }
    $rule{'minimum_version'} = 200;

    $rule{'_optionid'} = 0;

    if (length($rule{'original'}) > 1023) {
        minimum_version(\%rule, 240);
    }

    foreach my $option (@$options) {
        if (!defined($option->{'keyword'})) {
            return failed('parse options failed, no option');
        }
        if (defined($option->{'value'}) && length($option->{'value'}) > $self->max_ruleopt_len) {
            return failed($option->{'keyword'} . ' is too long');
        }

        if ($opt_parser->can($option->{'keyword'})) {
            my $keyword = $option->{'keyword'};
            my $ret = $opt_parser->$keyword(\%rule, $option->{'value'});
            return failed($ret) if ($ret);
        } else {
            return failed('unknown rule option ' . $option->{'keyword'});
        }
    }

    {
        my $error = verify_noalert(\%rule);
        return $error if ($error);
    }
    
    {
        my $error = verify_relative(\%rule);
        return $error if ($error);
    }
    
    {
        my $error = verify_class(\%rule);
        return $error if ($error);
    }

    if ($rule{'soid'} && $rule{'soid'} ne $rule{'gid'} . '|' . $rule{'sid'}) {
        return failed('soid must match gid/sid');
    }

    if (!$rule{'soid'} && $rule{'protocol'} eq 'tcp' && !$rule{'flow'}) {
        return failed("tcp rules must have flow or stateless");
    }
    delete($rule{'_rest'});
    return (\%rule);
}

sub minimum_version {
    my ($rule, $version) = @_;

    if (defined($rule->{'minimum_version'})) {
        $rule->{'minimum_version'} = $version
          if ($rule->{'minimum_version'} < $version);
    } else {
        $rule->{'minimum_version'} = $version;
    }
}

# this is an emulation of Snort's parse options functionality.  its slightly
# awful, but thank mfr for that one.
sub parse_options {
    my ($option) = @_;
    my $quoted   = 0;
    my $keyword  = 1;

    my $keyword_string = "";
    my $option_string  = "";

    my (@content) = map(chr, unpack("c*", $option));
    my (@options);

    while (@content) {
        while ($content[0] eq ' ') { shift(@content); }

        while ($keyword && @content) {
            my $s = shift(@content);
            if (!defined $s) {
                warn 'invalid keyword';
                return;
            }
            
            if ($s eq ";") {
                push(@options, { keyword => $keyword_string });
                $keyword_string = "";
                $keyword        = 1;
                last;
            } elsif ($s eq ':') {
                $keyword = 0;
                last;
            } else {
                $keyword_string .= $s;
            }
        }
        
        while ($content[0] eq ' ') { shift(@content); }

        while (!$keyword && @content) {
            my $s = shift(@content);

            if ($s eq '"') {
                $quoted = $quoted ? 0 : 1;
            } elsif ($s eq '\\') {
                $option_string .= $s;    # if ($quoted);
                $s = shift(@content);
            } elsif (!$quoted && $s eq ";") {
                push(@options, { keyword => $keyword_string, value => $option_string });
                $keyword_string = undef;
                $option_string  = undef;

                $keyword = 1;
                last;
            }

            # if I'm not in quote mode, undo backticks.
            $option_string .= $s;
        }
    }

    # if we are still in quoted mode, then the options arn't valid...
    warn "quoted string didn't end ($option)\n" if ($DEBUG && $quoted);
    return if ($quoted);
    return (\@options);
}

sub test_rule {
    require Data::Dumper;
    print Data::Dumper::Dumper(parse_rule($rule));
}

sub build_rule {
    my ($self, $rule, @rest) = self_or_default(@_);

    my (@opts);
    my %optomized;
    my %optomized_lone;

    my $header = join(" ",
        $rule->{'action'},  $rule->{'protocol'},  $rule->{'src'},
        $rule->{'srcport'}, $rule->{'direction'}, $rule->{'dst'},
        $rule->{'dstport'});

    foreach my $id (sort { $a <=> $b } keys %{ $rule->{'options'} }) {
        my $type = $rule->{'options'}->{$id}->{'type'};
        if (!defined($type)) {
            require Data::Dumper;
            die "Undefined type for $rule->{'sid'}:\n"
              . Data::Dumper::Dumper($rule);
        }

        if ($type eq 'content' || $type eq 'uricontent') {
            my $content = $rule->{'options'}->{$id}->{'optomized'};
            die "no content: sid $rule->{'sid'}: $content" if !length($content);

            if ($rule->{'options'}->{$id}->{'not'}) {
                push(@opts, "$type:!\"$content\";");
            } else {
                push(@opts, "$type:\"$content\";");
            }

            if ($rule->{'options'}->{$id}->{'relative'}) {
                if ($rule->{'options'}->{$id}->{'depth'}) {
                    push(@opts, "within:$rule->{'options'}->{$id}->{'depth'};");

                    # here, we see if exists as well as is non 0, since distance
                    # 0 with a within is a noop.
                    if ($rule->{'options'}->{$id}->{'offset'}) {
                        push(@opts,
                            "distance:$rule->{'options'}->{$id}->{'offset'};");
                    }
                } elsif (defined($rule->{'options'}->{$id}->{'offset'})) {
                    push(@opts,
                        "distance:$rule->{'options'}->{$id}->{'offset'};");
                }
            } else {
                if ($rule->{'options'}->{$id}->{'depth'}) {
                    push(@opts, "depth:$rule->{'options'}->{$id}->{'depth'};");

                    # here, we see if exists as well as is non 0, since distance
                    # 0 with a within is a noop.
                    if ($rule->{'options'}->{$id}->{'offset'}) {
                        push(@opts,
                            "offset:$rule->{'options'}->{$id}->{'offset'};");
                    }
                } elsif (defined($rule->{'options'}->{$id}->{'offset'})) {
                    push(@opts,
                        "offset:$rule->{'options'}->{$id}->{'offset'};");
                }
            }

            if ($rule->{'options'}->{$id}->{'nocase'}) {
                push(@opts, "nocase;");
            }
        } elsif ($type eq 'flow') {
            unshift(@opts,
                "flow:" . $rule->{'options'}->{$id}->{'original'} . ';');

#           unshift (@opts, "flow:" . join(",",sort keys %{$rule->{'options'}->{$id}->{'args'}}) . ";");
        } elsif (defined($rule->{'options'}->{$id}{'args'})) {

    #           if (defined $optomizable{$type}) {
    #              $optomized{$type}{$rule->{'options'}->{$id}{'args'}}++;
    #              # unshift(@opts, "$type:$rule->{'options'}->{$id}{'args'};");
    #           } else {
            push(@opts, "$type:$rule->{'options'}->{$id}{'args'};");

            #           }
        } else {

            #           if (defined $optomizable{$type}) {
            #               $optomized_lone{$type}++;
            #               # unshift (@opts, "$type;");
            #           } else {
            push(@opts, "$type;");

            #           }
        }
    }

    foreach my $otype (sort { $a cmp $b } keys %optomized) {
        foreach my $value (sort { $a cmp $b } keys %{ $optomized{$otype} }) {
            unshift(@opts, "$otype:$value;");
        }
    }

    foreach my $otype (sort { $a cmp $b } keys %optomized_lone) {
        unshift(@opts, "$otype;");
    }

    my $msg = $rule->{'name'};
    $msg =~ s/([\\:;\(\)])/\\$1/g;
    unshift(@opts, "msg:\"$msg\";");

    if ($rule->{'references'}) {
        foreach
          my $ref_type (sort { $a cmp $b } keys %{ $rule->{'references'} })
        {
            foreach my $ref (
                sort { $a cmp $b }
                keys %{ $rule->{'references'}->{$ref_type} }
              )
            {
                push(@opts, "reference:$ref_type,$ref;");
            }
        }
    }

    if ($rule->{'classification'}) {
        push(@opts, "classtype:$rule->{'classification'};");
    }

    push(@opts, "gid:$rule->{'gid'};")
      if ($rule->{'gid'} && $rule->{'gid'} != 1);
    push(@opts, "sid:$rule->{'sid'};") if (defined($rule->{'sid'}));

    if (defined($rule->{'revision'})) {

        # cheezy test to see if we have changed the rule any...
        if (!defined($self->{'noautorev'}) || !$self->{'noautorev'}) {
            my (@test) = (@opts, "rev:$rule->{'revision'};");
            my $test_rule = $header . " (" . join(" ", @test) . ")";
            if (!$rule->{'state'}) {
                $test_rule = "# " . $test_rule;
            }
            if ($test_rule ne $rule->{'original'}) {

                #           print "Rule changed\n";
                #           print "FROM: $rule->{'original'}\n";
                #           print "TO  : $test_rule\n";
                $rule->{'revision'}++;
            } else {

       #           print "DIDN'T CHANGE $rule->{'sid'} : $rule->{'original'}\n";
            }
        }
        push(@opts, "rev:$rule->{'revision'};");
    }

    my $string = $header . " (" . join(" ", @opts) . ")";
    if (!$rule->{'state'}) {
        $string = "# " . $string;
    }
    return ($string);
}

sub failed {
    my ($string) = @_;
    my %rule = (failed => $string);
    return (\%rule);
}

1;
