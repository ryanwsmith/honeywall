#!/usr/bin/perl
#
# $Id: RuleOptions.pm,v 1.6 2007/09/23 22:28:28 bmc Exp $
#
# Copyright (C) 2006 Brian Caswell <bmc@shmoo.com>
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
# 3. All advertising materials mentioning features or use of this software
#    must display the following acknowledgement:
#       This product includes software developed by Brian Caswell.
# 4. The name of the author may not be used to endorse or promote products
#    derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
# IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
# OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
# NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
# THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
# THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#

=head1 NAME

Net::Snort::Parser::RuleOptions - An Internal interface for rule options

=head1 NOTES

This module is not ment for public use.

=head1 AUTHOR

Brian Caswell <bmc@shmoo.com>

=head1 REPORTING BUGS

Report bugs to <bmc@shmoo.com>

=head1 THANKS

Thanks to The Honeynet Project

=head1 COPYRIGHT

Copyright (c) 2006 Brian Caswell <bmc@shmoo.com>

=head1 SEE ALSO

L<snort(8)>

=cut

package Net::Snort::Parser::RuleOptions;
use strict;
use warnings;
use Exporter;
use vars qw($AUTOLOAD $VERSION @ISA @EXPORT);

my %fields = (rule => undef);

sub new {
    my $that  = shift;
    my $class = ref($that) || $that;
    my $self  = {
        %fields,
    };

    bless $self, $class;

    if (@_) {
        my %conf = @_;
        while (my ($k, $v) = each %conf) {
            $self->$k($v);
        }
    }

    return $self;
}

my %unparsed_options = map { $_, 1 } qw(dsize ip_proto sameip fragbits flags ttl ipopts icmp_id tag threshold ack icmp_seq rpc seq id window byte_test);

$unparsed_options{'ftpbounce'} = 240;
$unparsed_options{'asn1'} = 220;

foreach my $method (keys %unparsed_options) {
    no strict 'refs';
    *$method = sub {
        use strict 'refs';
        my ($self, $rule, $value) = @_;

        my %option = ( 'type' => $method, args => $value);
        $self->add_option($rule, \%option, $unparsed_options{$method});

        return;
    };
}


my %location_options = ('http_client_body' => 261, 'http_uri' => 261, 'rawbytes' => 200);

foreach my $method (keys %location_options) {
    no strict 'refs';
    *$method = sub {
        use strict 'refs';
        my ($self, $rule, $value) = @_;

        if (defined $value) {
            return $method . ' with arguments';
        }

        if (!defined $rule->{'_contentid'} || $rule->{'_contentid'} == 0) {
            return $method . ' specified before content';
        }

        if (defined $rule->{'options'}{$rule->{'_contentid'}}{'location'}) {
            return 'content location modifier already specified';
        }

        $rule->{'options'}{$rule->{'_contentid'}}{'location'} = $method;
        return;
    }
}

sub metadata {
    my ($self, $rule, $value) = @_;

    my %valid_options = (
            'soid' => {
            'store' => 1,
            'unique' => 1,
            're' => qr/^\d+\|\d+$/
            },
            'engine' => {
            'unique' => 1,
            'values' => [qw(shared)]
            },
            'rule-type' => {
                'unique' => 1,
                'values' => [qw(preproc decode)],
            },
            'policy' => {
            're' => qr/^(balanced-ips|security-ips|connectivity-ips) (alert|drop|pass)$/
            },
            'service' => {
            'values' => [qw( aim bgp bootps chargen cvspserver daytime dcerpc dhcpv6-server discard dns echo exec finger font-service ftp ftp-data  gopher hostname  http ident imap ircd kerberos  ldap ldp linuxconf  login mysql nameserver nessus netbios-dgm netbios-ns netbios-ssn nntp ntalk ntp pop3 postgresql radacct radius rfb rsync rtsp shell smtp snmp snmp-trap  socks ssh ssl sunrpc syslog talk telnet tftp traceroute vnc-server whois x11 )]
            },
            'dependency' => {
            'values' => [qw( ftptelnet http_inspect dcerpc ssh )]
            }
            );



    my %seen;
    foreach my $meta (split(/\s*,\s*/, $value)) {
        my ($key, $value) = split(/ /, $meta, 2);
        $value =~ s/^\s*(.*?)\s*$/$1/;

        return "invalid metadata option ($key)" if (!$valid_options{$key});
        return "multiple metadata option ($key)" if ($valid_options{$key}{'unique'} && defined $seen{$key});

        if ($valid_options{$key}{'re'}) {
            return "invalid metadata value for $key ($value)" if $value !~ /$valid_options{$key}{'re'}/;
        }
        if ($valid_options{$key}{'values'}) {
            my $valid;
            foreach my $possible (@{ $valid_options{$key}{'values'} }) {
                if ($possible eq $value) {
                    $valid++;
                    last;
                }
            }
            return "invalid metadata value for $key ($value)" if !$valid;
        }

        $seen{$key}{$value}++;
        $rule->{$key} = $value if ($valid_options{$key}{'store'});
    }
    $rule->{'metadata'} = \%seen;
    minimum_version($rule, 261);

    return;
}

sub flowbits {
    my ($self, $rule, $value) = @_;

    my ($type, $data) = split(/\s*,\s*/, $value, 2);
    if ($type =~ /^is(not)?set/) {
        $rule->{'requires'}{$data} = 1;
    } elsif ($type =~ /^(un)?set/) {
        $rule->{'provides'}{$data} = 1;
    } elsif ($type eq 'noalert') {
        # do nothing...
    } else {
        return 'invalid flowbit type';
    }
    
    my %option = ('type' => 'flowbits', args => $value);
    $self->add_option($rule, \%option, 211);

    return;
}


{
    my %flow_options = map { $_, 1 } qw(to_server from_server to_client from_client established no_stream stateless only_stream);

    sub flow {
        my ($self, $rule, $value) = @_;

        if ($rule->{'flow'}) {
            return 'duplicate flow statements';
        }
        $rule->{'flow'}++;

        my %option = ('type' => 'flow', original => $value);

        if ($rule->{'protocol'} eq 'udp') {
            minimum_version($rule, '280');
        } elsif ($rule->{'protocol'} ne 'tcp') {
            return 'flow used on non-tcp/udp rule';
        }

        foreach my $opt (split(/\s*,\s*/, $value)) {
            $opt = lc($opt);
            if (!defined $flow_options{$opt}) {
                return 'invalid flow option';
            }
            $option{'args'}{$opt} = 1;
        }
    
        $self->add_option($rule, \%option);

        return;
    }
}
  
sub isdataat {
    my ($self, $rule, $value) = @_;

    return 'isdataat: arguments required' if (!length($value));

    my @values = split(/\s*,\s*/, $value);
    return 'isdataat: too many options' if (scalar(@values) > 3);
    
    return 'isdataat: invalid size' if ($values[0] !~ /^\d+$/);
            
    my $min_version = 240;

    for (my $i = 1; $i <= $#values; $i++) {
        if ($values[$i] eq 'rawbytes') {
            $min_version = 261;
        } elsif ($values[$i] ne 'relative') {
            return 'isdataat: invalid option';
        }
    }

    my %option = ( 'type' => 'isdataat', 'args' => join(',', @values) );
    $self->add_option($rule, \%option, $min_version);
    return ;
}

sub stateless {
    my ($self, $rule, $value) = @_;
    
    if ($rule->{'flow'}) {
        return 'stateless being used with flow';
    }
    $rule->{'flow'}++;
    
    if (defined $value) {
        return 'stateless with arguments';
    }
        
    my %option = ('type' => 'flow',);
    $option{'args'}{'stateless'} = 1;
    $self->add_option($rule, \%option, 200);
    return;
}

sub itype {
    my ($self, $rule, $value) = @_;
    my %option = ('type' => 'itype', args => $value);
    
    if ($value =~ /(<|>)/) {
        $self->add_option($rule, \%option, 210);
    } else {
        $self->add_option($rule, \%option);
    }

    return;
}

sub icode {
    my ($self, $rule, $value) = @_;
    my %option = ('type' => 'icode', args => $value);
    
    if ($value =~ /(<|>)/) {
        $self->add_option($rule, \%option, 210);
    } else {
        $self->add_option($rule, \%option);
    }

    return;
}

sub byte_jump {
    my ($self, $rule, $value) = @_;
    my %option = ('type' => 'byte_jump', args => $value);
    
    if ($value =~ /from_beginning|multiplier/) {
        $self->add_option($rule, \%option, 230);
    } else {
        $self->add_option($rule, \%option);
    }
    
    return;
}

sub ftpdata  {
    my ($self, $rule, $value) = @_;
    my %option = ('type' => 'ftpdata');
    if (defined($value)) {
        return fail('ftpdata with arguments');
    }
    
    $self->add_option($rule, \%option, 240);
    
    return;
}

sub nocase {
    my ($self, $rule, $value) = @_;

    if ($rule->{'_contentid'} == 0) {
        return 'nocase specified before content';
    }

    if (defined $value) {
        return 'nocase with arguments';
    }

    $rule->{'options'}{$rule->{'_contentid'}}{'nocase'} = 1;
   
    return;
}

sub replace {
    my ($self, $rule, $value) = @_;

    if (!defined $rule->{'_contentid'}) {
        return 'replace specified before content';
    }

    if ($rule->{'_contentid'} == 0) {
        return 'replace specified before content';
    }

    $value =~ s/^"(.*)"$/$1/;
    my $content = parse_content($value);
    if (!defined($content) || !length($content)) {
        return 'invalid replace';
    }
        
    if (defined $rule->{'options'}{$rule->{'_contentid'}}{'location'}) {
        return 'invalid replace: modifying a non-normal content';
    }
   
    if (length($rule->{'options'}{$rule->{'_contentid'}}{'string'}) != length($content)) {
        return 'invalid replace: replace content must be the same length as content';
    }

    $rule->{'options'}{$rule->{'_contentid'}}{'replace'} = make_content_readable($content);

    return;
}

sub depth {
    my ($self, $rule, $value) = @_;
    if ($rule->{'_contentid'} eq 0) {
        return 'depth specified before content';
    }

    my $content = $rule->{'options'}{$rule->{'_contentid'}};

    if (defined($content->{'relative'}) && $content->{'relative'} eq 1) {
        return 'mixing relative and non-relative options on a single content';
    }

    if ($value < length($content->{'string'})) {
        return 'depth too small for content';
    }

    $content->{'depth'} = $value;
    $content->{'relative'} = 0;
    return;
}

sub offset {
    my ($self, $rule, $value) = @_;
    if ($rule->{'_contentid'} eq 0) {
        return 'offset specified before content';
    }

    my $content = $rule->{'options'}{$rule->{'_contentid'}};

    if (defined($content->{'relative'}) && $content->{'relative'} eq 1) {
        return 'mixing relative and non-relative options on a single content';
    }

    $content->{'offset'} = $value;
    $content->{'relative'} = 0;
    return;
}

sub within {
    my ($self, $rule, $value) = @_;
    if ($rule->{'_contentid'} eq 0) {
        return 'within specified before content';
    }

    my $content = $rule->{'options'}{$rule->{'_contentid'}};

    if (defined($content->{'relative'}) && $content->{'relative'} eq 0) {
        return 'mixing relative and non-relative options on a single content';
    }

    if ($value < length($content->{'string'})) {
        return 'within too small for content';
    }

    $content->{'depth'} = $value;
    $content->{'relative'} = 1;

    return;
}

sub distance {
    my ($self, $rule, $value) = @_;
    if ($rule->{'_contentid'} eq 0) {
        return 'distance specified before content';
    }

    my $content = $rule->{'options'}{$rule->{'_contentid'}};

    if (defined($content->{'relative'}) && $content->{'relative'} eq 0) {
        return 'mixing relative and non-relative options on a single content';
    }

    $content->{'offset'} = $value;
    $content->{'relative'} = 1;
    return;
}

sub content {
    my ($self, $rule, $value) = @_;

    my %option = ('type' => 'content');

    if ($value =~ s/^\s*!//) {
        $option{'not'} = 1;
    }

    $value =~ s/^"(.*)"$/$1/;
    my $content = parse_content($value);
    if (!defined($content) || !length($content)) {
        return 'invalid content';
    }

    $option{'original'} = $value;
    $option{'string'} = $content;
    $option{'optomized'} = make_content_readable($content);
    
    $rule->{'_contentid'} = $self->add_option($rule, \%option);

    return;
}

sub uricontent {
    my ($self, $rule, $value) = @_;

    my %option = ('type' => 'content', 'location' => 'http_uri');
    
    if ($value =~ s/^\s*!//) {
        $option{'not'} = 1;
    }

    $value =~ s/^"(.*)"$/$1/;
    my $content = parse_content($value);
    if (!defined($content) || !length($content)) {
        return 'invalid content';
    }

    $option{'original'} = $value;
    $option{'string'} = $content;
    $option{'optomized'} = make_content_readable($content);
    
    $rule->{'_contentid'} = $self->add_option($rule, \%option);

    return;
}


sub rev {
    my ($self, $rule, $value) = @_;

    if (defined($rule->{'revision'})) {
        return 'multiple rev keywords';
    }

    if ($value !~ /^\d+$/) {
        return 'invalid rev';
    }

    $rule->{'revision'} = $value;

    return;
}

sub msg {
    my ($self, $rule, $value) = @_;

    if (defined($rule->{'name'})) {
        return 'multiple msg keywords';
    }
   
    if ($value !~ s/^\s*"(.*)"\s*$/$1/) {
        return 'msg arguments must be wrapped in double quotes (' . $value .')';
    }

    if ($value =~ /[();:]/) {
        return 'msg must not contain (, ), :, or "';
    }

    $rule->{'name'} = $value;

    return;
}

{
    my %ref_types = (
        url => qr/.*/,
        cve => qr/^(?:(?:cve|can)-)?\d{4}-\d{3,4}$/,
        mcafee => qr/.*/,
        bugtraq => qr/^\d+$/,
        arachnids => qr/^\d+$/,
        nessus => qr/^\d+$/,
    );
#    my %ref_types = map { $_, 1 } qw( url cve nessus mcafee bugtraq arachnids );
    sub reference {
        my ($self, $rule, $value) = @_;
        my ($ref_type, $ref_value) = split(/\s*,\s*/, $value, 2);
        $ref_type = lc($ref_type);
        if (!defined $ref_types{$ref_type}) {
            return 'invalid reference type (' . $ref_type .')';
        }
        if (!defined $ref_value) {
            return 'invalid reference value';
        }
        $ref_value =~ s/^\s*(.*)\s*$/$1/;
        $ref_value =~ s/^(CAN|CVE)-// if ($ref_type eq 'cve');
       
        return 'Invalid reference value : ' . $ref_value if ($ref_value !~ $ref_types{$ref_type});
        if (defined($rule->{'references'}{$ref_type}{$ref_value})) {
            return 'duplicate reference (' . $ref_type .',' . $ref_value . ')';
        }
        $rule->{'references'}{$ref_type}{$ref_value}++;
    }
}
    
{
    my %valid_classes = map { $_, 1 } qw( not-suspicious unknown bad-unknown attempted-recon successful-recon-limited successful-recon-largescale attempted-dos successful-dos attempted-user unsuccessful-user successful-user attempted-admin successful-admin rpc-portmap-decode shellcode-detect string-detect suspicious-filename-detect suspicious-login system-call-detect tcp-connection trojan-activity unusual-client-port-connection network-scan denial-of-service non-standard-protocol protocol-command-decode web-application-activity web-application-attack misc-activity misc-attack icmp-event kickass-porn policy-violation default-login-attempt );
    sub classtype {
        my ($self, $rule, $value) = @_;

        if (defined($rule->{'classification'})) {
            return 'multiple classtypes';
        }

        if (!defined($valid_classes{$value})) {
            return 'invalid classtype';
        }

        $rule->{'classification'} = $value;

        return;
    }
}

sub sid {
    my ($self, $rule, $value) = @_;
    if (defined($rule->{'sid'})) {
        return 'multiple sids defined for rule';
    }
    if ($value !~ /^\d+$/) {
        return 'invalid sid';
    }
    
    $rule->{'sid'} = $value;

    return;
}

sub gid {
    my ($self, $rule, $value) = @_;
    if (defined($rule->{'gid'})) {
        return 'multiple gids defined for rule';
    }
    if ($value !~ /^\d+$/) {
        return 'invalid gid';
    }
    
    $rule->{'gid'} = $value;

    return;
}

sub add_option {
    my ($self, $rule, $option, $minimum_version) = @_;
 
    $rule->{'_optionid'}++;
    $rule->{'options'}{$rule->{'_optionid'}} = $option;
   
    if ($minimum_version) {
        minimum_version($rule, $minimum_version);
    }

    return $rule->{'_optionid'};
}

sub pcre {
    my ($self, $rule, $value) = @_;

    return 'invalid pcre, missing arguments' if (!$value);

    return 'invalid pcre: parse failed' if (!parse_pcre($value));
    
    my %option = ('type' => 'pcre', args => $value);
    $self->add_option($rule, \%option, 210);

    return;
}

sub minimum_version {
    my ($rule, $version) = @_;

    if (defined($rule->{'minimum_version'})) {
        $rule->{'minimum_version'} = $version
          if ($rule->{'minimum_version'} < $version);
    } else {
        $rule->{'minimum_version'} = $version;
    }
}

# lets emulate the bad juju that snort's parser implements!
sub parse_pcre {
    my ($pcre) = @_;
    
    my (@content) = map(chr,unpack("c*", $pcre));
 
    # handle not pcre
    shift(@content) if $content[0] eq '!';
   
    # must start & end with "
    return if shift(@content) ne '"';
    return if pop(@content) ne '"';

    # regexp options
    while ($content[-1] =~ /^[ismxAEGRUB]$/) {
        pop(@content); 
    }

    # m|fooo| or /fooo/
    if ($content[0] eq 'm') {
        shift(@content);
        return if (shift(@content) ne pop(@content));
    } else {
        return if shift(@content) ne '/';
        return if pop(@content) ne '/';
    }

    while(@content) {
        my $a = shift(@content);
        return if $a eq ':';
        shift(@content) if ($a eq '\\'); # allow escaping of characters
    }

    return 1;
}

# lets emulate the bad juju that snort's parser implements!
sub parse_content {
    my ($content) = @_;
    my $end       = "";
    my $hex2a     = "";

    my $hexmode = 0;
    my (@content) = unpack("c*", $content);
    my $string;
    while (@content) {
        my $s = chr(shift(@content));

        if ($s eq "|" && $hexmode eq 0) {
            $hexmode++;
            next;
        }

        if ($s eq "|" && $hexmode eq 1) {
            $hexmode = 0;
            next;
        }

        # if I'm backticked...
        $s = chr(shift(@content)) if ($s eq '\\');

        if ($hexmode) {

            # skip spaces in hexmode
            $s = chr(shift(@content)) while ($s eq ' ');
            my $hex = $s;

            if ($s eq '|') {
                $hexmode = 0;
                next;
            }

            #grab the next one...
            $s = chr(shift(@content));

            # skip spaces in hexmode
            $s = chr(shift(@content)) while ($s eq ' ');

            if ($s eq '|') {
                warn "specified hex foo is too short\n";
                return
            }

            $hex .= $s;

            $s = chr(hex($hex));
        }
        $string .= $s;
    }

    # if we are still in hexmode, then the content string isn't valid...
    if ($hexmode) {
        return;
    }
    return ($string);
}

sub make_content_readable {
    my ($string) = @_;

    $string =~ s/([\0-\37\42-\44\x28\x29\x92\x5c\x7c\x3a\x3b\177-\377])/'|' . uc(unpack('H*', $1)) . '|'/eg;
    $string =~ s/\|\|/ /g;
    return $string;
}

1;
